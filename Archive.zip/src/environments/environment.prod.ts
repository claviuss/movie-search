export const environment = {
  production: true,
  omdbapiKey: '408ca71b',
  omdbApiUrl: 'http://www.omdbapi.com'
};
